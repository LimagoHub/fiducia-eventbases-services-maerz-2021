# spring-kafka-spring-integration-helloworld

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-spring-integration-helloworld)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-spring-integration-helloworld)

A detailed step-by-step tutorial on how to connect Apache Kafka to a Spring Integration Channel using Spring Kafka and Spring Boot.

[https://www.codenotfound.com/spring-kafka-spring-integration-example.html](https://www.codenotfound.com/spring-kafka-spring-integration-example.html)
