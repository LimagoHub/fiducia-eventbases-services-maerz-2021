java -cp target/uber-SimpleMovingAvg-1.0-SNAPSHOT.jar com.shapira.examples.zkconsumer.simplemovingavg.SimpleMovingAvgZkConsumer localhost:2181 avg shapira1 10 100000
