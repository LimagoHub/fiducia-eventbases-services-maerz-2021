# spring-kafka-json

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-json)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-json)

A detailed step-by-step tutorial on how to configure a JSON Serializer &amp; Deserializer using Spring Kafka and Spring Boot.

[https://www.codenotfound.com/spring-kafka-json-serializer-deserializer-example.html](https://www.codenotfound.com/spring-kafka-json-serializer-deserializer-example.html)
