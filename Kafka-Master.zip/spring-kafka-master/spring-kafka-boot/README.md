# spring-kafka-boot

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-boot)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-boot)

A detailed step-by-step tutorial on setting up Spring Kafka using Spring Boot autoconfiguration.

[https://www.codenotfound.com/spring-kafka-boot-example.html](https://www.codenotfound.com/spring-kafka-boot-example.html)
