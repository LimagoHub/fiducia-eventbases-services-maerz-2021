java -cp target/uber-SimpleCounter-1.0-SNAPSHOT.jar com.shapira.examples.producer.simplecounter.SimpleCounter "$@"
