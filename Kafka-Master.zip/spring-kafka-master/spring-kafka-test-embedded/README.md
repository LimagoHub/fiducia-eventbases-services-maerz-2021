# spring-kafka-test-embedded

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-test-embedded)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-test-embedded)

A detailed step-by-step tutorial on how to unit test your Spring Kafka application using an embedded server.

[https://www.codenotfound.com/spring-kafka-embedded-unit-test-example.html](https://www.codenotfound.com/spring-kafka-embedded-unit-test-example.html)
