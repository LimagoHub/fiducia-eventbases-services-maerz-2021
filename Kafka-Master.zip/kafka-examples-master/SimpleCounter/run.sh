java -cp target/uber-SimpleCounter-1.0-SNAPSHOT.jar com.shapira.examples.producer.simplecounter.SimpleCounter localhost:9092 v1 new async 500 10
