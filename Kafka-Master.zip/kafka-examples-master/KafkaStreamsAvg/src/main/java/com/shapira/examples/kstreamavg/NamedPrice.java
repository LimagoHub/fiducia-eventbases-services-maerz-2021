package com.shapira.examples.kstreamavg;


public class NamedPrice {
    String name;
    Integer price;

    public NamedPrice(String name, Integer price) {
        this.name = name;
        this.price = price;
    }
}
