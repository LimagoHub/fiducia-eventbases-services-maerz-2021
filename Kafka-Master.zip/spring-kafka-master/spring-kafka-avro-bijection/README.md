# spring-kafka-avro-bijection

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-avro-bijection)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-avro-bijection)

A detailed step-by-step tutorial on how to implement an Avro Serializer &amp; Deserializer using Twitter Bijection, Spring Kafka and Spring Boot.

[https://www.codenotfound.com/spring-kafka-avro-bijection-example.html](https://www.codenotfound.com/spring-kafka-avro-bijection-example.html)
