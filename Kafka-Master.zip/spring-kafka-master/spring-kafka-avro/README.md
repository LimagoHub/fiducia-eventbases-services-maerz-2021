# spring-kafka-avro

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-avro)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-avro)

A detailed step-by-step tutorial on how to implement an Apache Avro Serializer &amp; Deserializer using Spring Kafka and Spring Boot.

[https://www.codenotfound.com/spring-kafka-apache-avro-serializer-deserializer-example.html](https://www.codenotfound.com/spring-kafka-apache-avro-serializer-deserializer-example.html)
