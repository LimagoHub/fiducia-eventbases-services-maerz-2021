# spring-kafka-test-single-embedded

An example project that illustrates how you can run a single embedded Kafka broker for multiple test classes.

[https://www.codenotfound.com/spring-kafka/](https://www.codenotfound.com/spring-kafka/)
