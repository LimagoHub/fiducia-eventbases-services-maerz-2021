# spring-kafka

[![Build Status](https://travis-ci.org/code-not-found/spring-kafka.svg?branch=master)](https://travis-ci.org/code-not-found/spring-kafka)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)

This repository contains the source code for the spring-kafka examples posted on [https://www.codenotfound.com/spring-kafka/](https://www.codenotfound.com/spring-kafka/)

In case of questions or remarks please leave a comment in the respective blog post. Thanks!
