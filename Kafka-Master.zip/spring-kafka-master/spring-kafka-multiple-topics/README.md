# spring-kafka-multiple-topics

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=com.codenotfound:spring-kafka-multiple-topics)](https://sonarqube.com/dashboard/index/com.codenotfound:spring-kafka-multiple-topics)

A detailed step-by-step tutorial on how to consume different message types from multiple Kafka topics using Spring Kafka and Spring Boot.

[https://www.codenotfound.com/spring-kafka-consume-multiple-topics-example.html](https://www.codenotfound.com/spring-kafka-consume-multiple-topics-example.html)
